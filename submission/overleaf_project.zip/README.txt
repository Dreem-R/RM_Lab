Overleaf project — upload this zip via "New Project > Upload Project".

Compiler: pdfLaTeX. Main document: main.tex. Bibliography: refs.bib (BibTeX).
llncs.cls (version 2.25, 03-Sep-2026) and splncs04.bst are the official
Springer LNCS files, taken from the Springer Nature LNCS Overleaf template
and included so the project compiles without extra setup.

The preamble follows the template: T1 font encoding, newtxtext/newtxmath
(Times Roman), and the Springer URL style.

Before submitting, edit the author block near the top of main.tex
The author block is already filled in.
