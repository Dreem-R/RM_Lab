Overleaf project — upload this zip via "New Project > Upload Project".

Compiler: pdfLaTeX. Main document: main.tex. Bibliography: refs.bib (BibTeX).
llncs.cls and splncs04.bst are the official Springer LNCS class and style,
included so the project compiles without extra setup.

Before submitting, edit the author block near the top of main.tex
(the line marked ">>> EDIT THESE THREE LINES BEFORE SUBMITTING <<<").
